<div class="container">
    <div class="jumbotron">
        <h2 class="h1">Selamat Datang!</h2>
        <p>
            Selamat datang di website <strong>Tracer Alumni Jurusan Teknologi Informasi POLIJE</strong>. Sebelum melakukan pendaftaran pra yudisium,
            sebaiknya Anda menyimak  <?php echo anchor('prosedur', 'Prosedur Pendaftaran'); ?> pra yudisium.
        </p>
       
        <p>Anda juga dapat mengetahui data <?php echo anchor('alumni', 'Alumni'); ?>.</p>
        <p>Jika Anda sudah memahami proses pendaftaran, silakan klik tombol "<strong>Daftar</strong>" di bawah ini!</p>
        <p><?php echo anchor('pendaftaran', 'Daftar', 'class="btn btn-primary btn-lg" role="button"'); ?></p>
		<p
    </div>
</div>