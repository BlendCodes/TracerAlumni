<div class="container">
    <h2><?php echo $title ?></h2>
    <hr>
    <table class="table table-striped table-bordered table-hover table-condensed" style="max-width: 500px">
        <thead>
        <tr>
            <th>Tanggal</th>
            <th>Kegiatan</th>
        </tr>
        </thead>

        <tbody>
        <tr>
            <td>Senin - Selasa ( 1 - 2 Juni 2014 )</td>
            <td>Pendaftaran</td>
        </tr>
        <tr>
            <td>Rabu - Kamis ( 3 - 4 Juni 2014 )</td>
            <td>Verifikasi</td>
        </tr>
        <tr>
            <td>Senin, 8 Juni 2014</td>
            <td>Ujian Tulis</td>
        </tr>
        <tr>
            <td>Rabu, 10 Juni 2014</td>
            <td>Pengumuman</td>
        </tr>
        <tr>
            <td>Kamis - Sabtu ( 11 - 13 Juni 2014 )</td>
            <td>Her-registrasi</td>
        </tr>
        </tbody>
    </table>
</div>