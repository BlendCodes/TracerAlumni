<h3><?php echo $message; ?></h3>


<p><?php echo anchor('myupload', 'Return'); ?></p>