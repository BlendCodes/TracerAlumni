<h1><?php echo $judul; ?></h1>
<div>Tabel User | <a class="btn btn-default" href="<?php echo base_url() ?>index.php/user/tambah">Tambah</a>
</div>
<table class="table">
    <tr>
        <td>No</td>
        <td>Username</td>
        <td>Password</td>
    </tr>
    <?php
    foreach ($rows as $row) {
        ?>
        <tr>
            <!--mengubah nomor urut sesuai start-->
            <td><?php echo ++$start; ?></td>
            <td><?php echo $row->username; ?></td>
            <td><?php echo $row->password; ?></td>
           
        </tr>
        <?php
    }
    ?> 
</table>
<!--tampilkan link pagination-->
<?php echo $pagination; ?>