<?php
class Mwisuda extends CI_Model {
    var $tabel = 'tb_mahasiswa'; //buat variabel tabel
 
    function __construct() {
        parent::__construct();
    }
	
	public function get_btp()
	{	
	$this->db->select('upload_btp');
	$this->db->where('id', $this->session->userdata('no_peserta'));
	return $this->db->get($this->tabel);
	}
 
}
?>