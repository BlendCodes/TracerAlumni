<?php
class Mupload extends CI_Model {
    var $tabel = 'tb_mahasiswa'; //buat variabel tabel
 
    function __construct() {
        parent::__construct();
    }
	
	public function get_data()
	{
		$this->db->where('id', $data['id']);
		
		$q = $this->db->get($this->table, $data);
		$up_data = $q->result_array();
		
		/*foreach ($up_data->result() as $row)
		{
			$return[] = $row->regra_descricao;
		}
		return $return;
		*/
	}
 
    //fungsi insert ke database
    function get_update($data){
		$this->db->where('id', $data['id']);
		return $this->db->update($this->tabel, $data);
    }
}
?>