<?php
// Untuk membentuk nomor peserta (20140009)
$config['psb_prefix_no_peserta']    = '2014';
// Untuk mengirim email
$config['psb_email_panitia']        = 'panitiapsb@localhost';
$config['psb_email_nama']           = 'Panitia PSB SMP Putih Biru';

// Tahap/fase PSB, untuk menentukan disable/enable halaman Hasil seleksi.
// Nilai: "pendaftaran" / "pengumuman."
$config['psb_tahap_psb'] = 'pendaftaran';
//$config['psb_tahap_psb'] = 'pengumuman';