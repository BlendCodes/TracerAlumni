<?php
class Public_Controller extends MY_Controller
{
    // Layout untuk "Publik"
    public $layout = 'layout';
}