<?php
class Prayudisium_form extends Public_Controller
{
    public $data = array(
        'main_view' => 'prayudisium_form',
        'title'  => 'Data Peserta',
    );
}